package loadTestingComponent;

public class Main_LoadTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LoadTester loadTester = new LoadTester();
		loadTester.start(args);

	}

}
