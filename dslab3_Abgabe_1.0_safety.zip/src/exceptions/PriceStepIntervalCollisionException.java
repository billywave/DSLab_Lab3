package exceptions;

import java.rmi.RemoteException;

public class PriceStepIntervalCollisionException extends RemoteException {

	private static final long serialVersionUID = 3078259728662366820L;
    
}
