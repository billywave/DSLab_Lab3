package exceptions;

import java.rmi.RemoteException;

public class PriceStepIntervalNotFoundException extends RemoteException {

	private static final long serialVersionUID = 688522632466310197L;
    
}
