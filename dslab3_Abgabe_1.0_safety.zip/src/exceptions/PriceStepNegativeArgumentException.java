package exceptions;

import java.rmi.RemoteException;

public class PriceStepNegativeArgumentException extends RemoteException {

	private static final long serialVersionUID = 4817898881441847111L;
	
}
