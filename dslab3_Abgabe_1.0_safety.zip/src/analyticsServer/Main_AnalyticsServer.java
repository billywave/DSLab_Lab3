package analyticsServer;

public class Main_AnalyticsServer {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		AnalyticsServer analyticsServer = new AnalyticsServer();
		analyticsServer.startAnalyticsServer(args);
		
	}

}
